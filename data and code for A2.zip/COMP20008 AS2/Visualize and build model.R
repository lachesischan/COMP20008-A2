data = read.csv("/Users/xuzihan/Desktop/unimelb/Sem1/COMP20008/AS2/finaldata.csv")
attach(data)
area <- data$Area.name
rent <- data$Median_rent_weekly
person_income <- data$Median_tot_prsnl_inc_weekly
vehicle_hold <- data$avg_vel_hold
mental_health <- data$mental_help.ratio

#visualization
hist(person_income, main = 'fig 1: Distribution of Weekly Income')
hist(rent, main = 'fig 2: Distribution of Rent Paid')
hist(vehicle_hold, main = 'fig 3: Distribution of Average Vehicle Hold')
hist(mental_health, main = 'fig 4: Distribution of Ratio of People seeking mental help')

#income vs mental health
plot(person_income, mental_health, data = data, main = "fig 4: Mental Health vs Weekly Income")
abline(lm(mental_health~person_income))

#rent vs mental health
plot(rent, mental_health, data = data, main = "fig 5: Mental Health vs Rent Paid")
abline(lm(mental_health~rent))

#vehicle hold vs mental health
plot(vehicle_hold, mental_health, data = data, main = "fig 6: Mental Health vs Vehicle Hold")
abline(lm(mental_health~vehicle_hold))


#Anova
fit <- lm(mental~rent+car+income, data = final)
summary(fit)
anova(fit)

fit1 <- lm(mental~rent+income, data = final)
summary(fit1)
anova(fit1)

anova(fit,fit1)








